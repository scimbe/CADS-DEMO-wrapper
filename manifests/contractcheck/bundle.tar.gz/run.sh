#!/usr/bin/env bash
# Binary-kind entrypoint for contractcheck: compares two PDFs on BOTH text and images.
# Text half is deterministic (pdftotext -> difflib); the visual half renders each page
# (pdftoppm) and compares them with a vision model when an LLM key is present. Runs against
# the repo's committed fixture contracts (Clause 4 payment term changes 30 -> 45 days).
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export PYTHONPATH="$SCRIPT_DIR/vendor"
REPORT="$SCRIPT_DIR/report.md"
OLD="$SCRIPT_DIR/fixtures/contract_v1.pdf"; NEW="$SCRIPT_DIR/fixtures/contract_v2.pdf"
if [ -n "${LLM_BASE_URL:-}" ] && [ -n "${LLM_API_KEY:-}" ]; then
  echo "LLM key set -- full compare: text diff + LLM summary + visual (vision) comparison"
  python3 "$SCRIPT_DIR/src/pipeline.py" compare --old "$OLD" --new "$NEW" --report "$REPORT"
else
  echo "No LLM key -- tool-computed text diff only (no LLM/vision)"
  python3 "$SCRIPT_DIR/src/pipeline.py" compare --old "$OLD" --new "$NEW" --report "$REPORT" --no-llm --no-vision
fi
echo; echo "=== report.md ==="; cat "$REPORT"
